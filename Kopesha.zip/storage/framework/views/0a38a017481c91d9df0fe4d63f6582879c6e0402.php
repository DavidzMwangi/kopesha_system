<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('template/vendors/datatables/css/dataTables.bootstrap.css')); ?>" />
    <link href="<?php echo e(asset('template/css/pages/tables.css')); ?>" rel="stylesheet" type="text/css" />

    
    <link href="<?php echo e(asset('template/vendors/modal/css/component.css')); ?>" rel="stylesheet" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <h1>Transactions</h1>
        <ol class="breadcrumb">
            <li>
                <a href="<?php echo e(url('home')); ?>">
                    <i class="livicon" data-name="home" data-size="16" data-color="#000"></i>
                    Dashboard
                </a>
            </li>
            <li>Transactions</li>
            <li class="active">Completed Transactions</li>
        </ol>
    </section>






    <section class="content paddingleft_right15">
        <div class="row">
            <div class="panel panel-primary ">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <i class="livicon" data-name="user" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i>
                        Completed Transactions
                    </h4>
                </div>
                <br />
                <div class="panel-body">
                    <table class="table table-bordered " id="table">
                        <thead>
                        <tr class="filters">
                            
                            
                            <th>Debtor Id No</th>
                            <th>
                                Lender Id No
                            </th>
                            <th>Amount</th>
                            <th>Interest Gained</th>
                            <th>Payment Duration</th>
                            <th>Remaining Days</th>
                            <th>Payment Status</th>
                            <th>Edit</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $completedTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $completedTransaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($completedTransaction->debtor_id_no); ?></td>
                                <td>
                                    <?php echo e($completedTransaction->lender_id_no); ?></td>

                                <td>  <?php echo e($completedTransaction->amount); ?></td>
                                <td>  <?php echo e(((($completedTransaction->interest_rate_pm)/100)*$completedTransaction->amount)*$completedTransaction->payment_duration); ?></td>

                                <td>    <?php echo e($completedTransaction->payment_duration); ?> Months                     </td>
                                <td>   <?php echo e((\Carbon\Carbon::parse($completedTransaction->payment_end_date))->diffInDays(\Carbon\Carbon::now())); ?>             </td>
                                <td>

                                    <?php ($data=$completedTransaction->payment()->orderBy('id','desc')->first()); ?>
                                    <?php if($data['remaining_amount']==' '): ?>
                                        <span class="label label-sm label-success">Completed</span>
                                    <?php elseif($data['remaining_amount']>0): ?>

                                        <span class="label label-sm label-danger">Incomplete</span>
                                    <?php else: ?>
                                        <span class="label label-sm label-danger">No Payment Made</span>

                                    <?php endif; ?>

                                  

                                    
                                    
                                    
                                    
                                    
                                    
                                </td>
                                <td>
                                    
                                    <a href="#" data-toggle="modal" data-target="#edit_modal" onclick="getId4Modal(<?php echo e($completedTransaction->id); ?>);getDuration(<?php echo e($completedTransaction->payment_duration); ?>)" class="btn btn-primary">Edit
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <!-- Modal for showing transaction confirmation -->
                    <div class="modal fade" id="edit_modal" tabindex="-1" role="dialog" aria-labelledby="user_delete_confirm_title" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                    <h4 class="modal-title" id="user_delete_confirm_title">
                                        Edit Transaction
                                    </h4>
                                </div>
                                <form action="<?php echo e(url('edit_completed_transaction')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                <div class="modal-body">

                                    <input id="transaction_id" type="hidden" name="editted_transaction_id">
                                        <label for="edit_duration">Enter The Transaction Duration</label>
                                    <input class="form-control" id="edit_duration" name="edit_duration" type="number" min="1" required>

                                </div>
                                <div class="modal-footer">
                                    <button  class="btn btn-default pull-left"  name="cancel_button" value="button_cancel" data-dismiss="modal">Cancel</button>

                                    <input  type="submit" class="btn btn-success pull-right" value="Confirm" id="confirm_button" name="confirm_button" >
                                </div>
                                </form>

                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
        <!-- row--> </section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('template/vendors/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('template/vendors/datatables/dataTables.bootstrap.js')); ?>"></script>

    
    <script src="<?php echo e(asset('template/vendors/modal/js/classie.js')); ?>"></script>
    <script src="<?php echo e(asset('template/vendors/modal/js/modalEffects.js')); ?>"></script>
    <script type="application/javascript">
        function getId4Modal(transactionId) {
            $('#transaction_id').val(transactionId)
        }
        function getDuration(payment_time) {
            $('#edit_duration').val(payment_time)
        }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
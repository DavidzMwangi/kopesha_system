<aside class="left-side sidebar-offcanvas">
    <section class="sidebar ">
        <div class="page-sidebar  sidebar-nav">
            <div class="nav_icons">
                <ul class="sidebar_threeicons">
                    <li>
                        <a href="form_builder.html">
                            <i class="livicon" data-name="hammer" title="Form Builder 1" data-loop="true" data-color="#42aaca" data-hc="#42aaca" data-s="25"></i>
                        </a>
                    </li>
                    <li>
                        <a href="form_builder2.html">
                            <i class="livicon" data-name="list-ul" title="Form Builder 2" data-loop="true" data-color="#e9573f" data-hc="#e9573f" data-s="25"></i>
                        </a>
                    </li>
                    <li>
                        <a href="buttonbuilder.html">
                            <i class="livicon" data-name="vector-square" title="Button Builder" data-loop="true" data-color="#f6bb42" data-hc="#f6bb42" data-s="25"></i>
                        </a>
                    </li>
                    <li>
                        <a href="gridmanager.html">
                            <i class="livicon" data-name="new-window" title="Page Builder" data-loop="true" data-color="#37bc9b" data-hc="#37bc9b" data-s="25"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="clearfix"></div>
        
        <!-- BEGIN SIDEBAR MENU -->
            <ul id="menu" class="page-sidebar-menu">
                    
                <li >
                    <a href="<?php echo e(url('home')); ?>">
                        <i class="livicon" data-name="home" data-size="18" data-c="#418BCA" data-hc="#418BCA" data-loop="true"></i>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                
                <li>
                    <a href="#">
                        <i class="livicon" data-name="users" data-size="18" data-c="#00bc8c" data-hc="#00bc8c" data-loop="true"></i>
                        <span class="title">Users</span>
                        <span class="fa arrow"></span>
                    </a>
                    <ul class="sub-menu">
                        <li>
                            <a href="<?php echo e(url('allusers')); ?>">
                                <i class="fa fa-angle-double-right"></i>
                               All Users
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('edituser')); ?>">
                                <i class="fa fa-angle-double-right"></i>
                                Add New User
                            </a>
                        </li>
                        
                            
                                
                                
                            
                        
                        <li>
                            <a href="<?php echo e(url('deletedusers')); ?>">
                                <i class="fa fa-angle-double-right"></i>
                                Deleted Users
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(url('lenders')); ?>">
                        <i class="livicon" data-c="#F89A14" data-hc="#F89A14" data-name="users" data-size="18" data-loop="true"></i>
                        <span class="badge badge-danger"><?php echo e(count(\App\Models\Lender::all())); ?></span>

                        Lenders
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(url('debtors')); ?>">
                        <i class="livicon"  data-c="#00bc8c" data-hc="#00bc8c" data-name="users" data-size="18" data-loop="true"></i>
                        <span class="badge badge-danger"><?php echo e(count(\App\Facades\Debtor::Debtor()->all())); ?></span>
                        Debtors
                    </a>
                </li>

                
                <li>
                    <a href="#">
                        
                        <i class="livicon" data-name="money" data-size="18" data-c="#fff" data-hc="#fff" data-loop="true"></i>

                        <span class="title">Transactions</span>
                        <span class="fa arrow"></span>
                    </a>
                    <ul class="sub-menu">
                        <li>
                            <a href="<?php echo e(url('transactions')); ?>">
                                <i class="fa fa-angle-double-right"></i>
                                New Transaction
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('processingTransactions')); ?>">
                                <i class="fa fa-angle-double-right"></i>
                                Processing Transactions
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('completed_transactions')); ?>">
                                <i class="fa fa-angle-double-right"></i>
                                Completed Transactions
                            </a>
                        </li>
                    </ul>
                </li>
                
                <li>
                    <a href="#">
                        
                        <i class="livicon" data-name="money" data-size="18" data-c="#5bc0de" data-hc="#5bc0de" data-loop="true"></i>

                        <span class="title">Payments</span>
                        <span class="fa arrow"></span>
                    </a>
                    <ul class="sub-menu">
                        <li>
                            <a href="<?php echo e(url('add_payment')); ?>">
                                <i class="fa fa-angle-double-right"></i>
                                Make a Payment
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('all_payments')); ?>">
                                <i class="fa fa-angle-double-right"></i>
                                All Payments
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('completed_payments')); ?>">
                                <i class="fa fa-angle-double-right"></i>
                                Completed Payments
                            </a>
                        </li>
                    </ul>
                </li>

                
                


                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                    
                
                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                    
                
                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
                
                    
                        
                        
                        
                    
                    
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                        
                            
                                
                                
                            
                        
                    
                
            </ul>
            <!-- END SIDEBAR MENU -->
        </div>
    </section>

    <!-- /.sidebar -->
</aside>
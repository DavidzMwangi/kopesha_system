<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('template/vendors/datatables/css/dataTables.colReorder.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('template/vendors/datatables/css/dataTables.scroller.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('template/vendors/datatables/css/dataTables.bootstrap.css')); ?>" />
    <link href="<?php echo e(asset('template/css/pages/tables.css')); ?>" rel="stylesheet" type="text/css">

    
    <link href="<?php echo e(asset('template/vendors/select2/select2.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('template/vendors/select2/select2-bootstrap.css')); ?>" />


    

    
    
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <!--section starts-->
        <h1>All Payments</h1>
        <ol class="breadcrumb">
            <li>
                <a href="<?php echo e(url('home')); ?>">
                    <i class="livicon" data-name="home" data-size="18" data-loop="true"></i>
                    Home
                </a>
            </li>
            <li>
                <a href="#">Payment</a>
            </li>
            <li class="active">All Payments</li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-primary filterable">
                    <div class="panel-heading clearfix  ">
                        <div class="panel-title pull-left">
                            <div class="caption">
                                <i class="livicon" data-name="camera-alt" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i>
                                TableTools
                            </div>

                        </div>
                        <div class="tools pull-right"></div>

                    </div>
                    <div class="panel-body">
                        
                        <table class="table table-striped table-responsive" id="table1">
                            <thead>
                            <tr>

                                <th>Debtor Id No</th>
                                <th>Lender Id No</th>
                                <th>Total Amount <br>and Interest</th>
                                <th>Payment <br>Duration</th>
                                <th>Interest Rate PM</th>
                                <th>Amount Paid</th>
                                <th>Remaining<br> Amount</th>
                                <th>Transaction Date</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($payment->debtor_id_no); ?></td>
                                    <td><?php echo e($payment->transaction->first()->lender_id_no); ?></td>
                                    <td><?php echo e($payment->transaction->first()->total_amount_and_interest); ?></td>
                                    <td><?php echo e($payment->transaction->first()->payment_duration); ?></td>
                                    <td><?php echo e($payment->transaction->first()->interest_rate_pm); ?> Months</td>
                                    <td><?php echo e($payment->amount_paid); ?></td>
                                    <td><?php echo e($payment->remaining_amount); ?></td>
                                    <td><?php echo e($payment->created_at); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('template/vendors/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('template/vendors/datatables/dataTables.tableTools.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('template/vendors/datatables/dataTables.colReorder.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('template/vendors/datatables/dataTables.scroller.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('template/vendors/datatables/dataTables.bootstrap.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('template/js/pages/table-advanced.js')); ?>"></script>
    
    <script src="<?php echo e(asset('template/vendors/select2/select2.js')); ?>" type="text/javascript"></script>


    <script src="<?php echo e(asset('template/vendors/input-mask/jquery.inputmask.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/input-mask/jquery.inputmask.date.extensions.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/input-mask/jquery.inputmask.extensions.js')); ?>" type="text/javascript"></script>
    <!-- date-range-picker -->
    <script src="<?php echo e(asset('template/vendors/daterangepicker/daterangepicker.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/iCheck/icheck.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/iCheck/demo/js/custom.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/autogrow/js/jQuery-autogrow.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/maxlength/bootstrap-maxlength.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/card/jquery.card.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/js/pages/formelements.js')); ?>" type="text/javascript"></script>

    <!-- end of page level js -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('template/vendors/jasny-bootstrap/css/jasny-bootstrap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('template/vendors/daterangepicker/css/daterangepicker-bs3.css')); ?>" rel="stylesheet" type="text/css" />
    <!--select css-->
    <link href="<?php echo e(asset('template/vendors/select2/select2.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('template/vendors/select2/select2-bootstrap.css')); ?>" />
    <!--clock face css-->
    <link href="<?php echo e(asset('template/vendors/iCheck/skins/all.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('template/css/pages/formelements.css')); ?>" rel="stylesheet" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <!--section starts-->
        <h1>Transaction</h1>
        <ol class="breadcrumb">
            <li>
                <a href="<?php echo e(url('home')); ?>">
                    <i class="livicon" data-name="home" data-size="14" data-loop="true"></i>
                    Home
                </a>
            </li>
            <li>
                <a href="#">Transaction</a>
            </li>
            <li class="active">New Transaction</li>
        </ol>
    </section>
    <!--section ends-->
    <section class="content">
        <!--main content-->
        <div class="row">
            <!--row starts-->
            <div class="col-md-12">
                <!--md-12 starts-->
                <!--form control starts-->
                <div class="panel panel-success" id="hidepanel6">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <i class="livicon" data-name="share" data-size="16" data-loop="true" data-c="#fff" data-hc="white"></i>
                            New Transaction
                        </h3>
                        <span class="pull-right">
                                    <i class="glyphicon glyphicon-chevron-up clickable"></i>
                                    <i class="glyphicon glyphicon-remove removepanel clickable"></i>
                                </span>
                    </div>
                    <div class="panel-body">
                        <form method="post" action="<?php echo e(url('new_transaction')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group col-md-12">
                                
                                <div class="col-md-6">
                                <label>Debtor Id No</label>
                                
                                
                                    <select id="debtorSelector" class="form-control select2" name="debtor_id_no" onchange="getAllLenders(this.value);getMaxAmount(this.value)" required>
                                        <option disabled selected>Select Debtor</option>

                                    <?php $__currentLoopData = $debtors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $debtor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($debtor->user->id_no); ?>" ><?php echo e($debtor->user->id_no); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>


                                    
                                </div>
                                
                                <div class="col-md-6">
                                    <label for="all_lenders"> Lender Id No</label>
                                    <select id="all_lenders" class="form-control select2" onchange="lenderSelect(this.value)" name="lender_id">
                                        
                                        
                                            
                                       
                                    </select>

                                    
                                    
                                </div>
                            </div>
                            <div class="col-md-12" id="lenders_details">
                               <div class="col-md-6">
                                   <label class="control-label" for="interest_rate">Interest Rate per Month</label>
                                   <input type="text" class="form-control" id="interest_rate"  readonly>
                                   <input type="hidden" name="submit_interest_rate" id="submit_interest_rate">
                               </div>
                            <div class="form-group has-success col-md-offset-6">
                                <label class="control-label" for="inputSuccess">Amount the Lender can lend</label>
                                <input type="text" class="form-control" id="inputSuccess" disabled>
                            </div>

                            </div>
                            
                            <input type="hidden" id="tester_maximum">

                            <div class="col-md-12">
                                <div class="form-group col-md-6">

                                    <label>Select the Amount to Borrow</label>
                                    <input class="form-control"  id="amount_borrow" name="amount_borrow"  placeholder="Enter Amount to Borrow" required>
                                </div>

                                <div class="form-group col-md-6">
                                    <label>Enter the Duration of Payment in months</label>
                                    <input class="form-control" type="number" name="payment_duration" placeholder="Enter Payment Duration in Months" onclick="paymentDuration()" min="0"></div>

                            </div>

                            <div class="col-md-12">
                                <input type="submit" class="btn btn-primary" value="Save New Transaction">
                            </div>
                        </form>

                            

                             
                                
                                    
                                    
                                

                                
                                    
                                    

                            


                            

                            
                            
                                
                                    
                                
                                
                                    
                                        
                                    
                                    
                                
                                
                            
                            
                                
                                
                            
                            
                                
                                
                            
                            
                                
                                
                                    
                                        
                                
                                
                                    
                                        
                                
                                
                                    
                                        
                                
                            
                            
                                
                                
                                    
                                
                                    
                                
                                    
                            
                            
                                
                                
                                    
                                        
                                
                                
                                    
                                        
                                
                                
                                    
                                        
                                
                            
                            
                                
                                
                                    
                                
                                    
                                
                                    
                            
                            
                                
                                
                                    
                                    
                                    
                                    
                                    
                                
                            
                            
                                
                                
                                    
                                    
                                    
                                    
                                    
                                
                            
                            
                                
                                    
                                        
                                    
                                    
                                                
                                                    
                                                    
                                                    
                                        
                                    
                                
                            
                            
                            
                    </div>
                </div>
            </div>

        </div>
        <!--main content ends--> </section>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('template/vendors/jasny-bootstrap/js/jasny-bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('template/vendors/input-mask/jquery.inputmask.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/input-mask/jquery.inputmask.date.extensions.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/input-mask/jquery.inputmask.extensions.js')); ?>" type="text/javascript"></script>
    <!-- date-range-picker -->
    <script src="<?php echo e(asset('template/vendors/daterangepicker/daterangepicker.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/select2/select2.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/iCheck/icheck.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/iCheck/demo/js/custom.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/autogrow/js/jQuery-autogrow.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/maxlength/bootstrap-maxlength.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/vendors/card/jquery.card.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('template/js/pages/formelements.js')); ?>" type="text/javascript"></script>
        <script type="application/javascript">
            //first hide the div until the user clicks the select 2 of the lender
            $('#lenders_details').hide();

            //clear the lender selector 2 when dentor selector is clicked again
            $('#debtorSelector').click(function () {
                $('#lenders_details').hide();

                $('#all_lenders').empty();
            });
            //display the lenders first
            function getAllLenders(debtor_id_no) {
                //send the selected debtor id_no
                var url1='<?php echo e(url('getLenderFromDebtor')); ?>';
                axios.post(url1,{'post_debtor_id_no':debtor_id_no})
                    .then(function (result22) {
                        $('#all_lenders').append("<option  disabled selected>Select A Lender</option>");

                        $.each(result22.data.possible_lenders,function (key,value) {
                            $('#all_lenders').append("<option   value='"+value.id+"'>"+value.user.id_no+"</option>")
                        })
                    })
            }

            function lenderSelect(lenderid) {
//                alert(lenderid)
                //display the div after user selects the select2 input
                $('#lenders_details').show();
                //first post the id to get the details of the lender
                var url3='<?php echo e(url('lender_details')); ?>';
                axios.post(url3,{'lenderid':lenderid})
                    .then(function (result) {
                        //display the maximum value the debtorcan borrow
                        $('#inputSuccess').val((result.data.lenderData.max_amount)-(result.data.lenderData.lended_amount));
                        $('#interest_rate').val(result.data.lenderData.interest_rate_pm + "%");
                        $('#submit_interest_rate').val(result.data.lenderData.interest_rate_pm);
                    });

            }
            function paymentDuration() {
                var num1=$('#amount_borrow').val();
                var num2=$('#inputSuccess').val();
                //check whether the value is grater than the amount that can be borrowed4

                if ((num1-num2)>0 ){
//                    alert(num2-num1);
                    alert("The value is greater than the amount you can borrow");
                    $('#amount_borrow').val(null);
                }
                var num12=$('#tester_maximum').val();
                if((num1-num12)>0){
                    alert("The money has exceeded the maximum amount of debt the user can borrow")
                }
            }
            //function to get the max amount the debtor can borrow
            function getMaxAmount(debtor_id_no) {
                var url5='<?php echo e(url('getDebtorMaxValue')); ?>';
                axios.post(url5,{'debtor_id_no_4_max':debtor_id_no})
                    .then(function (result6) {
                        var maximum=result6.data.debtor_max_limit.max_limit_debt;
                       $('#tester_maximum').val(maximum);
//                        alert(result6.data.debtor_max_limit.max_limit_debt)
                    })
            }

        </script>
    <script type="application/javascript">

    </script>
    <!-- end of page level js -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Testapp::Application.config.secret_token = '412cfb8d8bc8bdf1ebd1d91b077635cd9eaae339ee4f2fd2bd8882172fda7ac99a34e80974328a567ba6764c5dc2febbda4075ef9cae80baa29ba7632ab51ee9'
Testapp::Application.config.secret_key_base = 'new secret key base'

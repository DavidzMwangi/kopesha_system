module BootstrapWysihtml5Rails
  module Rails
    VERSION = "0.3.1.22"
  end
end

If this is a set of changes on bootstrap-wysihtml5 itself, then you want to make you pull request here:

https://github.com/jhollingworth/bootstrap-wysihtml5

If this is a set of changes on bootstrap-wysihtml5-rails, then go ahead
require('coffee-script/register');
require('./gulpfile.coffee');

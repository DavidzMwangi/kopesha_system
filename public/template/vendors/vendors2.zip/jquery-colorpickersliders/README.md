# jQuery Color Picker Sliders

An advanced responsive color selector with color swatches and support for human perceived lightness. Works in all modern browsers and on touch devices.

- [Website](http://www.virtuosoft.eu/code/jquery-colorpickersliders/)

Please report issues and feel free to make feature suggestions as well.

## License

Apache License, Version 2.0

[![githalytics.com alpha](https://cruel-carlota.pagodabox.com/9d4e22e4c9dbc544d294a0760564d39d "githalytics.com")](http://githalytics.com/istvan-ujjmeszaros/jquery-colorpickersliders)

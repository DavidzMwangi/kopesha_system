/* LivIcons v1.4 | (c) 2013 DeeThemes | livicons.com */

As you can see there is no any HTML or CSS files. This is not a mistake.

All icons list and their names you can see in the Customizer.

For correct usage of LivIcons please read the documentation. It's quite simple.

Thank you.